"""Invalid urls.py file for testing"""
urlpatterns = []
